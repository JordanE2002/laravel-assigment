<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Companies')); ?></div>

                <div class="card-body">
                    <?php if (isset($component)) { $__componentOriginalfd1f218809a441e923395fcbf03e4272 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfd1f218809a441e923395fcbf03e4272 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Company List <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $attributes = $__attributesOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__attributesOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $component = $__componentOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__componentOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>

                    <!-- Create -->
                    <?php if (isset($component)) { $__componentOriginala6d15d77335de01bd81addac814f21ff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6d15d77335de01bd81addac814f21ff = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.create-button','data' => ['route' => route('companies.create'),'label' => 'Create New Company']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('create-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('companies.create')),'label' => 'Create New Company']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6d15d77335de01bd81addac814f21ff)): ?>
<?php $attributes = $__attributesOriginala6d15d77335de01bd81addac814f21ff; ?>
<?php unset($__attributesOriginala6d15d77335de01bd81addac814f21ff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6d15d77335de01bd81addac814f21ff)): ?>
<?php $component = $__componentOriginala6d15d77335de01bd81addac814f21ff; ?>
<?php unset($__componentOriginala6d15d77335de01bd81addac814f21ff); ?>
<?php endif; ?>
                            <!-- Sort -->
                        <?php if (isset($component)) { $__componentOriginal5bbb9a719e5fcc735ceee6caad4f1123 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bbb9a719e5fcc735ceee6caad4f1123 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort-form','data' => ['action' => route('companies')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('companies'))]); ?>
                            <option value="name" <?php echo e(request('sort') === 'name' ? 'selected' : ''); ?>>Name</option>
                            <option value="email" <?php echo e(request('sort') === 'email' ? 'selected' : ''); ?>>Email</option>
                            <option value="website" <?php echo e(request('sort') === 'website' ? 'selected' : ''); ?>>Website</option>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bbb9a719e5fcc735ceee6caad4f1123)): ?>
<?php $attributes = $__attributesOriginal5bbb9a719e5fcc735ceee6caad4f1123; ?>
<?php unset($__attributesOriginal5bbb9a719e5fcc735ceee6caad4f1123); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bbb9a719e5fcc735ceee6caad4f1123)): ?>
<?php $component = $__componentOriginal5bbb9a719e5fcc735ceee6caad4f1123; ?>
<?php unset($__componentOriginal5bbb9a719e5fcc735ceee6caad4f1123); ?>
<?php endif; ?>
                    </div>

                    <!-- Company Cards -->
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-6 mb-4">
                                <div class="card shadow-sm h-100">
                                    <div class="card-body text-center">
                                        <?php echo $__env->make('auth.info.companies-logo', [
                                            'company' => $company,
                                            'width' => 100,
                                            'height' => 100
                                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                                        <h5 class="card-title mt-3"><?php echo e($company->name); ?></h5>
                                        <p class="card-text"><strong>Email:</strong> <?php echo e($company->email); ?></p>
                                        <p class="card-text">
                                            <strong>Website:</strong>
                                            <a href="<?php echo e($company->website); ?>" target="_blank"><?php echo e($company->website); ?></a>
                                        </p>

                                        <!-- Buttons -->
                                        <div class="d-flex justify-content-center gap-2 mt-3 flex-wrap">
                                            <a href="<?php echo e(route('companies.edit', $company->id)); ?>" class="btn btn-sm btn-warning">Edit</a>

                                            <form action="<?php echo e(route('companies.destroy', $company->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                            </form>

                                            <a href="<?php echo e(route('companies.employees', $company->id)); ?>" class="btn btn-sm btn-info">View Employees</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>No companies found.</p>
                        <?php endif; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if (isset($component)) { $__componentOriginal6b7f97cc5a6cdf26a8769abafc29181f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b7f97cc5a6cdf26a8769abafc29181f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pagination-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php echo e($companies->appends(request()->query())->links('vendor.pagination.bootstrap-5')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b7f97cc5a6cdf26a8769abafc29181f)): ?>
<?php $attributes = $__attributesOriginal6b7f97cc5a6cdf26a8769abafc29181f; ?>
<?php unset($__attributesOriginal6b7f97cc5a6cdf26a8769abafc29181f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b7f97cc5a6cdf26a8769abafc29181f)): ?>
<?php $component = $__componentOriginal6b7f97cc5a6cdf26a8769abafc29181f; ?>
<?php unset($__componentOriginal6b7f97cc5a6cdf26a8769abafc29181f); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jordan English\Herd\laravel-assigment\resources\views/auth/info/companies.blade.php ENDPATH**/ ?>