

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Employees at <?php echo e($company->name); ?></h2>

    <?php if($employees->count()): ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle shadow-sm">
                <thead class="table-dark">
                    <tr>
                        <th scope="col">Full Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Date Created</th> <!-- New Column for Date Created -->
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></td>
                            <td><?php echo e($employee->email); ?></td>
                            <td><?php echo e($employee->phone_number); ?></td>
                            <td><?php echo e($employee->created_at->format('D, M d, Y')); ?></td> <!-- Displaying the created_at date -->
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info mt-4">
            No employees found for this company.
        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('companies')); ?>" class="btn btn-secondary mt-4">
        ← Back to Companies
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jordan English\Herd\laravel-assigment\resources\views/auth/info/employees-by-company.blade.php ENDPATH**/ ?>