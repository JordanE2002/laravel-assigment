<div class="d-flex justify-content-center mt-4">
    <?php echo e($slot); ?>

</div><?php /**PATH C:\Users\Jordan English\Herd\laravel-assigment\resources\views/components/pagination-wrapper.blade.php ENDPATH**/ ?>