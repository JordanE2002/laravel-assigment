<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Basic Stats Section -->
    <div class="row text-center mb-4">
        <?php $__currentLoopData = [
            ['title' => 'Total Companies', 'count' => \App\Models\Companies::count()],
            ['title' => 'Total Employees', 'count' => \App\Models\Employees::count()],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 mb-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($stat['title']); ?></h5>
                    <p class="display-6"><?php echo e($stat['count']); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Most Recent Companies Section -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Most Recent Companies</h5>
                    <ul class="list-group">
                        <?php $__currentLoopData = \App\Models\Companies::latest()->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <?php echo e($company->name); ?> - <?php echo e($company->created_at->format('l, d, Y')); ?>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Most Recent Employees Section -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Most Recent Employees</h5>
                    <ul class="list-group">
                        <?php $__currentLoopData = \App\Models\Employees::latest()->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?> - <?php echo e($employee->created_at->format('M d, Y')); ?>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jordan English\Herd\laravel-assigment\resources\views/home.blade.php ENDPATH**/ ?>