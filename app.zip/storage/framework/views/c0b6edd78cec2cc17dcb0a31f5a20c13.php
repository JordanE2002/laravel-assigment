<div class="mb-4 d-flex justify-content-between align-items-center flex-wrap gap-3">
    <a href="<?php echo e($route); ?>" class="btn btn-primary">
        + <?php echo e($label); ?>

    </a>
</div>
<?php /**PATH C:\Users\Jordan English\Herd\laravel-assigment\resources\views/components/create-button.blade.php ENDPATH**/ ?>