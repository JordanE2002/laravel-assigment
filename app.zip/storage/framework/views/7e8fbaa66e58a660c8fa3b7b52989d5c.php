<h2 class="mb-4 text-xl font-semibold">
    <?php echo e($slot); ?>

</h2><?php /**PATH C:\Users\Jordan English\Herd\laravel-assigment\resources\views/components/header.blade.php ENDPATH**/ ?>