<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['company', 'width' => 100, 'height' => 100]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['company', 'width' => 100, 'height' => 100]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?> <!-- Default width and height are both 100 -->

<?php if($company->logo && file_exists(storage_path('app/public/' . $company->logo))): ?>
    <!-- Display the company's logo if it exists in storage -->
    <img src="<?php echo e(asset('storage/' . $company->logo)); ?>" alt="Company Logo" width="<?php echo e($width); ?>" height="<?php echo e($height); ?>" />
<?php else: ?>
    <!-- Display the fallback image (random generated image) if no logo exists -->
    <img src="http://picsum.photos/seed/<?php echo e(rand(0, 10000)); ?>/<?php echo e($height); ?>" alt="Company Logo" class="rounded-xl">
<?php endif; ?>
<?php /**PATH C:\Users\Jordan English\Herd\laravel-assigment\resources\views/auth/info/companies-logo.blade.php ENDPATH**/ ?>