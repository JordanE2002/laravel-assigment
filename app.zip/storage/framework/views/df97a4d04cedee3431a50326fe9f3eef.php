<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Employees')); ?></div>

                <div class="card-body">
                    <?php if (isset($component)) { $__componentOriginalfd1f218809a441e923395fcbf03e4272 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfd1f218809a441e923395fcbf03e4272 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Employee List <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $attributes = $__attributesOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__attributesOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $component = $__componentOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__componentOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>

                    <!-- Create -->
                    <?php if (isset($component)) { $__componentOriginala6d15d77335de01bd81addac814f21ff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6d15d77335de01bd81addac814f21ff = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.create-button','data' => ['route' => route('employees.create'),'label' => 'Create New Employee']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('create-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('employees.create')),'label' => 'Create New Employee']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6d15d77335de01bd81addac814f21ff)): ?>
<?php $attributes = $__attributesOriginala6d15d77335de01bd81addac814f21ff; ?>
<?php unset($__attributesOriginala6d15d77335de01bd81addac814f21ff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6d15d77335de01bd81addac814f21ff)): ?>
<?php $component = $__componentOriginala6d15d77335de01bd81addac814f21ff; ?>
<?php unset($__componentOriginala6d15d77335de01bd81addac814f21ff); ?>
<?php endif; ?>
                            <!-- Sort -->
                        <?php if (isset($component)) { $__componentOriginal5bbb9a719e5fcc735ceee6caad4f1123 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bbb9a719e5fcc735ceee6caad4f1123 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sort-form','data' => ['action' => route('employees')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sort-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('employees'))]); ?>
                            <option value="first_name" <?php echo e(request('sort') === 'first_name' ? 'selected' : ''); ?>>First name</option>
                            <option value="last_name" <?php echo e(request('sort') === 'last_name' ? 'selected' : ''); ?>>Last name</option>
                            <option value="email" <?php echo e(request('sort') === 'email' ? 'selected' : ''); ?>>Email</option>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bbb9a719e5fcc735ceee6caad4f1123)): ?>
<?php $attributes = $__attributesOriginal5bbb9a719e5fcc735ceee6caad4f1123; ?>
<?php unset($__attributesOriginal5bbb9a719e5fcc735ceee6caad4f1123); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bbb9a719e5fcc735ceee6caad4f1123)): ?>
<?php $component = $__componentOriginal5bbb9a719e5fcc735ceee6caad4f1123; ?>
<?php unset($__componentOriginal5bbb9a719e5fcc735ceee6caad4f1123); ?>
<?php endif; ?>
                    </div>

                    <!-- Employee Cards -->
                    <div class="row">
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 mb-4">
                                <div class="card shadow-sm h-100">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></h5>
                                        <p class="card-text"><strong>Email:</strong> <?php echo e($employee->email); ?></p>
                                        <p class="card-text">
                                            <strong>Company:</strong>
                                            <?php echo e($employee->company ? $employee->company->name : 'No company associated'); ?>

                                        </p>
                                        <p class="card-text"><strong>Phone:</strong> <?php echo e($employee->phone_number); ?></p>

                                        <!-- Buttons Row -->
                                        <div class="d-flex justify-content-start gap-2 mt-3 flex-wrap">
                                            <a href="<?php echo e(route('employees.edit', $employee->id)); ?>" class="btn btn-sm btn-warning">Edit</a>

                                            <form action="<?php echo e(route('employees.destroy', $employee->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <!-- Pagination -->
                    <?php if (isset($component)) { $__componentOriginal6b7f97cc5a6cdf26a8769abafc29181f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b7f97cc5a6cdf26a8769abafc29181f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pagination-wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php echo e($employees->appends(request()->query())->links('vendor.pagination.bootstrap-5')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b7f97cc5a6cdf26a8769abafc29181f)): ?>
<?php $attributes = $__attributesOriginal6b7f97cc5a6cdf26a8769abafc29181f; ?>
<?php unset($__attributesOriginal6b7f97cc5a6cdf26a8769abafc29181f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b7f97cc5a6cdf26a8769abafc29181f)): ?>
<?php $component = $__componentOriginal6b7f97cc5a6cdf26a8769abafc29181f; ?>
<?php unset($__componentOriginal6b7f97cc5a6cdf26a8769abafc29181f); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jordan English\Herd\laravel-assigment\resources\views/auth/info/employees.blade.php ENDPATH**/ ?>