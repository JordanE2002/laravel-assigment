<div class="d-flex justify-content-center mt-4">
    {{ $slot }}
</div>