<h2 class="mb-4 text-xl font-semibold">
    {{ $slot }}
</h2>