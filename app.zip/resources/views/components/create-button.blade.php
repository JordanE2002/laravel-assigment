<div class="mb-4 d-flex justify-content-between align-items-center flex-wrap gap-3">
    <a href="{{ $route }}" class="btn btn-primary">
        + {{ $label }}
    </a>
</div>
